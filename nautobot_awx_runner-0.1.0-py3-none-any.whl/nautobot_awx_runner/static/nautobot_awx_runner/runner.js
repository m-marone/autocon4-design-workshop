
/**
 * Used in conjuction with `job_result_modal` to pop up the modal, start the job, provide progress spinner, 
 * provide job status, job results link, redirect link, and error message.
 *
 * @requires nautobot_csrf_token - The CSRF token obtained from Nautobot.
 * @param {string} jobClass - The jobs `class_path` as defined on the job detail page.
 * @param {Object} data - The object containing payload data to send to the job.
 * @param {string} return_url - The URL to redirect to (optional)
 */
function startJob(jobClass, data, return_url) {
    var jobApi = `/api/extras/jobs/${jobClass}/run/`;

    $("#job-status-modal").modal({show: true, backdrop: "static", keyboard: false});
    $("#job-status-close").on("click", function() {
        $(this).addClass("disabled");
        if (return_url !== undefined) {
            window.location.replace(return_url);
        } else {
            $("#job-status-modal").modal("hide");
        }
    });

    const callBack = function(jobResultId) {
        return new Promise((resolve) => {
            resolve("Job Completed Successfully.");
        });
    };

    $.ajax({
        type: 'POST',
        url: jobApi,
        contentType: "application/json",
        data: JSON.stringify({data: data}),
        dataType: 'json',
        headers: {
            'X-CSRFToken': nautobot_csrf_token
        },
        beforeSend: function() {
            // Normalize to base as much as you can.
            $('#jobStatus').html("Pending").show();
            $('#loaderImg').show();
            $('#jobResults').hide();
            $('#redirectLink').hide();
            $('#detailMessages').hide();
        },
        success: function(jobData) {
            $("#loaderImg").hide();
            $('#jobStatus').html("Started").show();
            var jobResultUrl = "/extras/job-results/" + jobData.job_result.id + "/";
            $('#jobResults').html(iconLink(jobResultUrl, "mdi-open-in-new", "Job Details")).show();
            pollJobStatus(jobData.job_result.url, callBack);
            $("#job-status-close").removeClass("disabled");
        },
        error: function(e) {
            $("#loaderImg").hide();
            console.log("There was an error with your request...");
            console.log("error: " + JSON.stringify(e));
            $('#jobStatus').html("Failed").show();
            $('#detailMessages').show();
            $('#detailMessages').attr('class', 'alert alert-danger text-center');
            $('#detailMessages').html("<b>Error: </b>" + e.responseText);
            $("#job-status-close").removeClass("disabled");
        }
    });
}
  
/**
 * Polls the status of a job with the given job ID.
 *
 * This function makes an AJAX request to the server,
 * to get the current status of the job with the specified job ID.
 * It continues to poll the status until the job completes or fails.
 * The job status is updated in the HTML element with ID 'jobStatus'.
 * If the job encounters an error, additional error details are shown.
 * The call is not made async, so that the parent call will wait until
 * this is completed.
 *
 * @requires nautobot_csrf_token - The CSRF token obtained from Nautobot.
 * @param {string} jobId - The ID of the job to poll.
 * @returns {void}
 */
function pollJobStatus(jobId, callBack) {
$.ajax({
    url: jobId,
    type: "GET",
    async: false,
    dataType: "json",
    headers: {
        'X-CSRFToken': nautobot_csrf_token
    },
    success: function(data) {
        $('#jobStatus').html(data.status.value.charAt(0).toUpperCase() + data.status.value.slice(1)).show();
        if (["FAILURE", "REVOKED"].includes(data.status.value)) {
            $("#loaderImg").hide();
            $('#detailMessages').show();
            $('#detailMessages').attr('class', 'alert alert-warning text-center');
            $('#detailMessages').html("Job started but failed during the Job run. This job may have partially completed. See Job Results for more details on the errors.");
        } else if (["PENDING", "RECEIVED", "RETRY", "STARTED"].includes(data.status.value)) {
            // Job is still processing, continue polling
            setTimeout(function() {
                pollJobStatus(jobId, callBack);
            }, 1000); // Poll every 1 seconds
        } else if (["SUCCESS"].includes(data.status.value)) {
            $("#loaderImg").hide();
            $('#detailMessages').show();
            callBack(data.id)
                .then((message) => {
                    $('#redirectLink').show();
                    $('#detailMessages').attr('class', 'alert alert-success text-center');
                    $('#detailMessages').html(message)
                    $('#job-status-modal .runner-loading-container').hide()
                })
                .catch((message) => {
                    $('#detailMessages').attr('class', 'alert alert-warning text-center');
                    $('#detailMessages').html(message)
                })
        }
    },
    error: function(e) {
        $("#loaderImg").hide();
        console.log("There was an error with your request...");
        console.log("error: " + JSON.stringify(e));
        $('#detailMessages').show();
        $('#detailMessages').attr('class', 'alert alert-danger text-center');
        $('#detailMessages').html("<b>Error: </b>" + e.responseText);
    }
})
};
/**
 * Converts a list of form data objects to a dictionary.
 *
 * @param {FormData} formData - The form data object to be converted.
 * @param {string[]} listKeys - The list of keys for which values should be collected as lists.
 * @returns {Object} - The dictionary representation of the form data.
 */
function formDataToDictionary(formData, listKeys) {
    const dict = {};

    formData.forEach(item => {
        const {
            name,
            value
        } = item;
        if (listKeys.includes(name)) {
            if (!dict[name]) {
                dict[name] = [value];
            } else {
                dict[name].push(value);
            }
        } else {
            dict[name] = value;
        }
    });

    return dict;
}

/**
 * Renders a template string with placeholders replaced by corresponding values from jobData.
 *
 * @param {string} templateString - The template string with placeholders in the form of `{jobData.someKey}`.
 * @param {Object} jobData - The object containing data to replace placeholders in the template.
 * @returns {string} - The rendered string with placeholders replaced by actual values from jobData.
 */
function _renderTemplate(templateString, data) {
    // Create a regular expression to match placeholders in the template
    const placeholderRegex = /\{jobData\.([^\}]+)\}/g;

    // Replace placeholders with corresponding values from jobData
    const renderedString = templateString.replace(placeholderRegex, (match, key) => {
        const keys = key.split(".");
        let value = data;
        for (const k of keys) {
            if (value.hasOwnProperty(k)) {
                value = value[k];
            } else {
                return match; // If the key is not found, keep the original placeholder
            }
        }
        return value;
    });

    return renderedString;
}

/**
 * Generates an HTML anchor link with an icon.
 *
 * @param {string} url - The URL to link to.
 * @param {string} icon - The name of the Material Design Icon to use.
 * @param {string} title - The title to display when hovering over the icon.
 * @returns {string} - The HTML anchor link with the specified icon.
 */
function iconLink(url, icon, title) {
    const linkUrl = `<a href="${url}" target="_blank">` +
        `  <span class="text-primary">` +
        `    <i class="mdi ${icon}" title="${title}"></i>` +
        `  </span>` +
        `</a>`
    return linkUrl
}
