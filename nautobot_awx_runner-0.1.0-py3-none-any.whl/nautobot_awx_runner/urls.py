"""Django urlpatterns declaration for config compliance plugin."""
from nautobot.core.views.routers import NautobotUIViewSetRouter
from . import views

app_name = "nautobot_awx_runner"

router = NautobotUIViewSetRouter()

router.register("jobs", views.JobViewSet, basename="job")
router.register("job_templates", views.JobTemplateViewSet, basename="job_template")
router.register("workflow_job_templates", views.WorkflowJobTemplateViewSet, basename="workflow_job_template")
router.register("workflow_approvals", views.WorkflowApprovalViewSet, basename="workflow_approval")

urlpatterns = router.urls
