"""Django views for Nautobot Golden Configuration."""  # pylint: disable=too-many-lines
from typing import Any
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.urls import reverse
from django.shortcuts import render, HttpResponse
from django.template.loader import select_template
from django.template.response import TemplateResponse

from django_tables2 import RequestConfig

from rest_framework.viewsets import ViewSet
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, MultiPartParser

from nautobot.apps.views import GetReturnURLMixin

from . import NautobotAWXRunnerConfig
from .client.errors import AWXException
from .forms import launch_form_factory
from . import tables


def awx_error_handler(method):
    """Decorator that handles AWXError exceptions and returns an error view.

    Args:
        method (callable): Method to decorate
    """

    def wrapped(self, request, *args, **kwargs):
        try:
            return method(self, request, *args, **kwargs)
        except AWXException as ex:
            return render(
                request,
                "nautobot_awx_runner/error.html",
                context={
                    "error": str(ex),
                },
            )

    return wrapped


class APIProxyUIViewSet(PermissionRequiredMixin, GetReturnURLMixin, ViewSet):
    """A view set for API proxy endpoints."""

    api_model = None
    parser_classes = [FormParser, MultiPartParser]

    def check_permissions(self, request):
        """Confirm the user has permissions for the view."""
        user = self.request.user
        permission_required = self.get_required_permission()
        # Check that the user has been granted the required permission(s) one by one.
        # In case the permission has `message` or `code`` attribute, we want to include those information in the permission_denied error.
        for permission in permission_required:
            # If the user does not have the permission required, we raise DRF's `NotAuthenticated` or `PermissionDenied` exception
            # which will be handled by self.handle_no_permission() in the UI appropriately in the dispatch() method
            # Cast permission to a list since has_perms() takes a list type parameter.
            if not user.has_perms([permission]):
                self.permission_denied(
                    request,
                    message=getattr(permission, "message", None),
                    code=getattr(permission, "code", None),
                )

    def get_required_permission(self):
        return self.get_permission_required()

    @awx_error_handler
    def retrieve(self, request, pk, *args, **kwargs):
        """Display the detail view for the view set."""
        instance = self.retrieve_endpoint(pk)
        template = select_template(
            [
                f"nautobot_awx_runner/{ self.api_model }_retrieve.html",
                "nautobot_awx_runner/api_proxy_retrieve.html",
            ]
        )
        return TemplateResponse(
            request,
            template,
            context={
                "object": self.api_model,
                "instance": instance,
                "verbose_name_plural": self.verbose_name_plural,
                "list_url": reverse(f"plugins:nautobot_awx_runner:{self.api_model}_list"),
            },
        )

    @awx_error_handler
    def list(self, request, *args, **kwargs):
        """Display the list view for the view set."""
        params = {k: v for (k, v) in request.GET.items() if v}
        params["order_by"] = params.pop("sort", "-id")
        params["page_size"] = params.pop("per_page", 25)
        data = self.list_endpoint(**params)

        template = select_template(
            [
                f"nautobot_awx_runner/{ self.api_model }_list.html",
                "nautobot_awx_runner/api_proxy_list.html",
            ]
        )
        return TemplateResponse(
            request,
            template,
            context={
                "table": RequestConfig(request).configure(self.table_class(data)),
                "title": self.verbose_name_plural,
                "return_url": self.get_return_url(request),
            },
        )


class JobViewSet(APIProxyUIViewSet):
    """View set for AWX Jobs."""

    permission_required = "nautobot_awx_runner.view_job"
    verbose_name_plural = "Job List"
    table_class = tables.JobsTable
    api_model = "job"

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the view set."""
        super().__init__(**kwargs)
        self.list_endpoint = NautobotAWXRunnerConfig.client.get_jobs
        self.retrieve_endpoint = NautobotAWXRunnerConfig.client.get_job

    @action(detail=True, url_name="output")
    def output(self, request, pk):
        return render(
            request,
            "nautobot_awx_runner/inc/job_output.html",
            context={
                "events": NautobotAWXRunnerConfig.client.get_job_events(pk),
            },
        )


class JobMixin:
    """Mixin to retrieve the survey spec."""

    @action(detail=True, url_name="survey")
    def survey(self, request, pk):
        """Retrieve the survey (if any) for the associated job/workflow job."""
        template = self.detail_endpoint(id=pk)
        if template.get("survey_enabled", False):
            survey = self.survey_endpoint(id=pk)
            survey_name = template["name"].replace(" ", "")
            form_class = launch_form_factory(survey_name, survey)

            form = form_class()

            return render(
                request,
                "nautobot_awx_runner/inc/survey_form.html",
                context={"return_url": self.get_return_url(request), "form": form},
            )

        return HttpResponse(status=204)

    @action(detail=True, url_name="launch")
    def launch(self, request, pk):
        """Display the job/workflow job launch page."""
        return render(
            request,
            "nautobot_awx_runner/launch_job.html",
            context={
                "job_id": pk,
                "return_url": self.get_return_url(request),
                "job_class": self.launch_job_class,
                "survey_view": f"plugins:nautobot_awx_runner:{ self.api_model }_survey",
            },
        )


class JobTemplateViewSet(APIProxyUIViewSet, JobMixin):
    """View set to display information about job templates."""

    permission_required = "nautobot_awx_runner.view_jobtemplate"
    verbose_name_plural = "Job Template List"
    table_class = tables.JobTemplatesTable
    default_return_url = "plugins:nautobot_awx_runner:job_template_list"
    api_model = "job_template"

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the view set."""
        super().__init__(**kwargs)
        self.detail_endpoint = NautobotAWXRunnerConfig.client.get_job_template
        self.list_endpoint = NautobotAWXRunnerConfig.client.get_job_templates
        self.survey_endpoint = NautobotAWXRunnerConfig.client.get_job_template_survey_spec
        self.launch_job_class = "Launch Job Template"
        self.retrieve_endpoint = NautobotAWXRunnerConfig.client.get_job_template


class WorkflowJobTemplateViewSet(APIProxyUIViewSet, JobMixin):
    """View for individual device detailed information."""

    permission_required = "nautobot_awx_runner.view_workflowjobtemplate"
    verbose_name_plural = "Workflow Job Template List"
    table_class = tables.WorkflowJobTemplatesTable
    default_return_url = "plugins:nautobot_awx_runner:workflow_job_template_list"
    api_model = "workflow_job_template"

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the view set."""
        super().__init__(**kwargs)
        self.detail_endpoint = NautobotAWXRunnerConfig.client.get_workflow_job_template
        self.list_endpoint = NautobotAWXRunnerConfig.client.get_workflow_job_templates
        self.survey_endpoint = NautobotAWXRunnerConfig.client.get_workflow_job_template_survey_spec
        self.launch_job_class = "Launch Workflow Template"
        self.retrieve_endpoint = NautobotAWXRunnerConfig.client.get_workflow_job_template


class WorkflowApprovalViewSet(APIProxyUIViewSet):
    """View for individual device detailed information."""

    permission_required = "nautobot_awx_runner.view_workflowapproval"
    verbose_name_plural = "Workflow Approval List"
    table_class = tables.WorkflowApprovalTable
    api_model = "workflow_approval"

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the view set."""
        super().__init__(**kwargs)
        self.list_endpoint = NautobotAWXRunnerConfig.client.get_workflow_approvals
        self.retrieve_endpoint = NautobotAWXRunnerConfig.client.get_workflow_approval
