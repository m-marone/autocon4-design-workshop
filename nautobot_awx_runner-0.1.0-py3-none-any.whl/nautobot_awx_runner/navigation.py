"""Add the configuration compliance buttons to the Plugins Navigation."""

from nautobot.apps.ui import NavMenuGroup, NavMenuItem, NavMenuTab


items = (
    NavMenuItem(
        link="plugins:nautobot_awx_runner:job_list",
        name="Job List",
        permissions=["nautobot_awx_runner.view_job"],
    ),
    NavMenuItem(
        link="plugins:nautobot_awx_runner:job_template_list",
        name="Job Template List",
        permissions=["nautobot_awx_runner.view_jobtemplate"],
    ),
    NavMenuItem(
        link="plugins:nautobot_awx_runner:workflow_job_template_list",
        name="Workflow Job Template List",
        permissions=["nautobot_awx_runner.view_workflowjobtemplate"],
    ),
    NavMenuItem(
        link="plugins:nautobot_awx_runner:workflow_approval_list",
        name="Workflow Approval List",
        permissions=["nautobot_awx_runner.view_workflowapproval"],
    ),
)

menu_items = (
    NavMenuTab(
        name="Plugins",
        groups=(NavMenuGroup(name="AWX Runner", weight=1000, items=items),),
    ),
)
