"""Generic runner for interacting with AWX / Ansible Tower."""

from typing import List, Tuple, Union

from .endpoint import Endpoint

# TODO: write documentation about filtering using query params


class AWXClient:
    """A class for interacting with AWX or Ansible Tower."""

    # TODO: address redundancy between this implementation and the nautobot_net.tower.Tower class.
    # TODO: pagination support for API responses

    def __init__(self, base_url=None, username=None, password=None):
        """Instantiate an AWXRunner.

        By default this will pull the url, username, and password from environment variables, but as multiple
        Nautobot plugins might use this class, each with their own configuration, they are overridable by the caller.

        Args:
            base_url (str, optional): url string such as "https://tower.example.com".
            username (str, optional): Username for HTTP Basic auth.
            password (str, optional): Password for HTTP Basic auth.

        Raises:
            ValueError: If any of the configuration (base_url, username or password) are missing.
        """
        if not base_url or not username or not password:
            raise ValueError("Not all of base_url, username, or password were set - check environment and settings!")

        if base_url.endswith("/"):
            base_url = base_url.rstrip("/")

        if base_url.endswith("/api/v2"):
            base_url = base_url.rstrip("/api/v2")

        self.base_url = base_url
        self.username = username
        self.password = password
        self.approve_workflow_approval_endpoint = self._endpoint(
            "POST", "/workflow_approvals/{id}/approve/", retval=None
        )
        self.deny_workflow_approval_endpoint = self._endpoint("POST", "/workflow_approvals/{id}/deny/", retval=None)
        self.get_hosts_endpoint = self._endpoint("GET", "/hosts/", paging=True)
        self.get_job_endpoint = self._endpoint("GET", "/jobs/{id}/")
        self.get_job_events_endpoint = self._endpoint("GET", "/jobs/{id}/job_events", paging=True)
        self.get_job_stdout_endpoint = self._endpoint(
            "GET", "/jobs/{id}/stdout/", params={"format": "json"}, retval="content"
        )
        self.get_job_template_endpoint = self._endpoint("GET", "/job_templates/{id}/")
        self.get_job_template_survey_spec_endpoint = self._endpoint("GET", "/job_templates/{id}/survey_spec/")
        self.get_job_templates_endpoint = self._endpoint("GET", "/job_templates/", paging=True)
        self.get_jobs_endpoint = self._endpoint("GET", "/jobs/", paging=True)
        self.get_workflow_approval_endpoint = self._endpoint("GET", "/workflow_approvals/{id}/")
        self.get_workflow_approvals_endpoint = self._endpoint("GET", "/workflow_approvals/", paging=True)
        self.get_workflow_job_template_endpoint = self._endpoint("GET", "/workflow_job_templates/{id}")
        self.get_workflow_job_templates_endpoint = self._endpoint("GET", "/workflow_job_templates/", paging=True)
        self.get_workflow_job_template_survey_spec_endpoint = self._endpoint(
            "GET", "/workflow_job_templates/{id}/survey_spec/"
        )

        self.get_workflow_job_workflow_nodes_endpoint = self._endpoint(
            "GET", "/workflow_jobs/{id}/workflow_nodes/", paging=True
        )
        self.get_workflow_jobs_endpoint = self._endpoint("GET", "/workflow_jobs/", paging=True)
        self.launch_job_template_endpoint = self._endpoint("POST", "/job_templates/{id}/launch/")
        self.launch_workflow_job_template_endpoint = self._endpoint("POST", "/workflow_job_templates/{id}/launch/")

    def _endpoint(self, meth: str, url: str, **kwargs) -> Endpoint:
        """Create an API client endpoint.

        Args:
            meth (str): HTTP method (eg 'GET' or 'POST')
            url (str): URL of the endpoint, not including the base URL or '/api/v2'
            **kwargs: Additional arguments to pass along to the Endpoint constructor

        Returns:
            Endpoint: A callable endpoint prepared to generate requests.
        """
        return Endpoint(meth, f"{self.base_url}/api/v2{url}", auth=self._get_auth, **kwargs)

    def _get_auth(self) -> Tuple[str, str]:
        """Get the HTTP basic auth tuple.

        Returns:
            Tuple[str, str]: HTTP Basic username and password
        """
        return (self.username, self.password)

    def approve_workflow_approval(self, id: Union[int, str]) -> None:
        """Approve a pending workflow approval.

        Args:
            id (Union[int, str]): The ID of the pending approval.

        Returns:
            None
        """
        return self.approve_workflow_approval_endpoint(id=id).call()

    def deny_workflow_approval(self, id: Union[int, str]) -> None:
        """Deny a pending workflow approval.

        Args:
            id (Union[int, str]): The ID of the pending approval.

        Returns:
            None
        """
        return self.deny_workflow_approval_endpoint(id=id).call()

    def get_hosts(self, **query_params) -> List[dict]:
        """Get the list of hosts in inventory.

        Args:
            **query_params: Any query parameters to filter the results.

        Returns:
            List[dict]: A list of host entries. (See AWX API documentation for details).
        """
        return self.get_hosts_endpoint(params=query_params).call()

    def get_job(self, id: Union[int, str]) -> dict:
        """Get status of a given job instance.

        Args:
          id (Union[int, str]): Job ID

        Returns:
          dict: Describing the job
        """
        # TODO: for now we just proxy the exact AWX/Tower response, in future we might prune this somewhat
        return self.get_job_endpoint(id=id).call()

    def get_job_events(self, id: Union[int, str]) -> list:
        return self.get_job_events_endpoint(id=id).call()

    def get_job_stdout(self, id: Union[int, str]) -> str:
        """Get plaintext output of a given job instance.

        Args:
          id (Union[int, str]): Job ID

        Returns:
          str: Plaintext job output
        """
        # TODO: handle jobs that have more STDOUT lines than are returned in a single request
        return self.get_job_stdout_endpoint(id=id).call()

    def get_job_template(self, id: Union[int, str]) -> dict:
        """Look up a specific job template.

        Args:
          id (Union[int, str]): Job template ID

        Returns:
            dict: Describing the job template.
        """
        # TODO: for now we just proxy the exact AWX/Tower response, in future we might prune this somewhat
        return self.get_job_template_endpoint(id=id).call()

    def get_job_template_survey_spec(self, id: Union[int, str]) -> dict:
        """Get a single workflow job template survey spec.

        Args:
            id (Union[int, str]): The ID of the workflow job template.

        Returns:
            The template information.
        """
        return self.get_job_template_survey_spec_endpoint(id=id).call()

    def get_job_templates(self, **query_params) -> List[dict]:
        """Retrieve information about the job templates.

        Args:
            **query_params: Any query parameters to filter the results.

        Returns:
            List[dict]: List of all the job templates.
        """
        for template in self.get_job_templates_endpoint(params=query_params).call():
            template["url"] = self.get_job_template_ui_url(template["id"])
            yield template

    def get_job_template_ui_url(self, id: Union[int, str]) -> str:
        """Get the UI URL for a job template.

        Args:
            id (Union[int, str]): The ID of the job template

        Returns:
            str: The formatted URL to navigate to the job template in the AWX UI.
        """
        return f"{self.base_url}/#/templates/job_template/{id}/"

    def get_job_ui_url(self, id: Union[int, str]):
        """Get the Tower UI URL for a given job.

        Args:
          id (int, str): Job ID

        Returns:
          str: Constructed url
        """
        return f"{self.base_url}/#/jobs/playbook/{id}"

    def get_jobs(self, **query_params) -> List[dict]:
        """Get a list of jobs.

        Args:
            **query_params: Any query parameters to filter the results.

        Returns:
          List[dict]: A list of dictionaries describing the jobs.
        """
        for job in self.get_jobs_endpoint(params=query_params).call():
            job["url"] = self.get_job_ui_url(job["id"])
            yield job

    def get_workflow_approval(self, id: Union[int, str]) -> dict:
        """Look up a specific job template.

        Args:
            id (Union[int, str]): Workflow Approval ID

        Returns:
            dict: Dictionary describing the workflow approval.
        """
        return self.get_workflow_approval_endpoint(id=id).call()

    def get_workflow_approval_ui_url(self, id: Union[int, str]) -> str:
        """Get the UI URL for a workflow approval.

        Args:
            id (Union[int, str]): The ID of the workflow approval

        Returns:
            str: The formatted URL to navigate to the workflow approval in the AWX UI.
        """
        return f"{self.base_url}/#/workflow_approvals/{id}/"

    def get_workflow_approvals(self, **query_params) -> dict:
        """Get all workflow approvals.

        Args:
            **query_params: Any query parameters to filter the results.

        Returns:
            List[dict]: A list of dictionaries describing each approval.
        """
        for approval in self.get_workflow_approvals_endpoint(params=query_params).call():
            approval["url"] = self.get_workflow_approval_ui_url(approval["id"])
            yield approval

    def get_workflow_job_template(self, id: Union[int, str]) -> dict:
        """Get a single workflow job template.

        Args:
            id (Union[int, str]): The ID of the workflow job template.

        Returns:
            The template information.
        """
        return self.get_workflow_job_template_endpoint(id=id).call()

    def get_workflow_job_template_ui_url(self, id: Union[int, str]) -> str:
        """Get the UI URL for a workflow job template.

        Args:
            id (Union[int, str]): The ID of the workflow job template

        Returns:
            str: The formatted URL to navigate to the workflow job template in the AWX UI.
        """
        return f"{self.base_url}/#/templates/workflow_job_template/{id}/"

    def get_workflow_job_templates(self, **query_params) -> List[dict]:
        """Get a list of workflow job templates.

        Args:
            **query_params: Any query parameters to filter the results.

        Returns:
            List[dict]: List of dictionaries describing each job template.
        """
        for job in self.get_workflow_job_templates_endpoint(params=query_params).call():
            job["url"] = self.get_workflow_job_template_ui_url(job["id"])
            yield job

    def get_workflow_job_template_survey_spec(self, id: Union[int, str]) -> dict:
        """Get the survey spec for a given workflow.

        Args:
            id (Union[int, str]): The workflow ID.

        Returns:
            dict: The workflow survey
        """
        return self.get_workflow_job_template_survey_spec_endpoint(id=id).call()

    def get_workflow_job_workflow_nodes(self, id: Union[int, str], **query_params) -> List[dict]:
        """Get workflow nodes for a specific workflow job.

        Args:
            id (Union[int, str]): Workflow job ID.
            **query_params: Any query parameters to filter the results.

        Returns:
            List[dict]: List of dictionaries describing the workflow job nodes.
        """
        return self.get_workflow_job_workflow_nodes_endpoint(id=id, params=query_params).call()

    def get_workflow_jobs(self, **params) -> List[dict]:
        """Get a list of workflow jobs.

        Args:
            **params: Any query parameters to filter the results.

        Returns:
            List[dict]: List of dictionaries describing the workflow jobs.
        """
        return self.get_workflow_jobs_endpoint(params=params).call()

    def launch_job_template(self, job_template_id, **extra_vars) -> int:
        """Launch a job from a given template.

        Args:
          job_template_id (int, str): ID of the job template to launch.
          extra_vars (dict): Passed through as the contents of "extra_vars" in launching the job.

        Returns:
          int: The ID of the newly created job.
        """
        return self.launch_job_template_endpoint(id=job_template_id).call(extra_vars=extra_vars)

    def launch_workflow_job_template(self, id: Union[int, str], **extra_vars) -> int:
        """Launch a workflow job template.

        Args:
            id (id: Union[int, str]): The ID of the workflow job template.
            extra_vars (dict[str, Any]): Any extra vars needed to run the job.

        Returns:
            int: The newly created job ID.
        """
        return self.launch_workflow_job_template_endpoint(id=id).call(extra_vars=extra_vars)
