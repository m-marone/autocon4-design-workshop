"""Errors related to the AWX runner client endpoints."""
from requests.exceptions import RequestException, HTTPError


def cause(error: Exception) -> Exception:
    """Retrieve the underlying cause of the exception."""
    if isinstance(error, RequestException):
        return cause(error.args[0])
    elif getattr(error, "reason", None) is not None:
        return cause(getattr(error, "reason"))
    elif error.__cause__ is None:
        return error
    return cause(error.__cause__)


class AWXException(Exception):
    """Base class for all exceptions related to communicating with the AWX API."""

    def __init__(self, message, *args, **kwargs):
        """Create an AWX exception.

        Args:
            message (str): Details about the exception.
        """
        self.message = message
        super().__init__(*args, **kwargs)

    def __str__(self):
        """Get a user-friendly error message."""
        base = cause(self)
        # this seems like such a hack, but urllib3 always
        # includes the connection pool and other information
        # in the exception message, but all we really want
        # is the last bit (reason the exception occurred in the first place)
        if base is not self:
            message = str(base)
            if ":" in message:
                message = message.split(":")[-1].strip()

            # if the message also contains an error number, strip that
            # out so that it isn't confusing to the user
            if message.startswith("[") and "]" in message:
                message = message[message.find("]") + 1 :].strip()

            return f"{self.message}: {message}"
        return self.message


class ConnectionException(AWXException):
    """Exception related to connecting to API endpoints."""


class BadRequestException(AWXException):
    """Request that is malformed or cannot be processed by AWX."""


class UnauthorizedException(AWXException):
    """Request was not authorized for the configured user."""


class ForbiddenException(AWXException):
    """The configured user is not authorized to retrieve the requested data."""


class NotFoundException(AWXException):
    """The resource was not found."""


class MethodNotAllowedException(AWXException):
    """The HTTP method (GET,PUT,POST, etc) was not allowed for the requested endpoint."""


class NotAcceptableException(AWXException):
    """Endpoint returned an HTTP 406 status."""


class UnsupportedMediaTypeException(AWXException):
    """Endpoint returned an HTTP 415 status."""


class TooManyRequestsException(AWXException):
    """Endpoint returned an HTTP 429 status."""


class InternalServerErrorException(AWXException):
    """Endpoint returned an HTTP 500 status."""


class ServiceUnavailableException(AWXException):
    """Endpoint returned an HTTP 503 status."""


class InvalidResponseException(AWXException):
    """The returned data could not be processed for some reason."""


def error_report(function):
    """Method decorator to raise an exception based on HTTP status code.

    Args:
        function (callable): Method to decorate
    """

    def wrapper(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except HTTPError as e:
            if e.response.status_code == 400:
                raise BadRequestException("Malformed request: {}".format(e.response.text))
            elif e.response.status_code == 401:
                raise UnauthorizedException("Authentication Error: {}".format(e.response.text))
            elif e.response.status_code == 403:
                raise ForbiddenException(
                    "Insufficient permissions to execute request (ie, any POST method as a regular user): {}".format(
                        e.response.text
                    )
                )
            elif e.response.status_code == 404:
                raise NotFoundException(
                    "Attempting to access an endpoint that does not exist: {}".format(e.response.text)
                )
            elif e.response.status_code == 405:
                raise MethodNotAllowedException(
                    "Wrong request type for target endpoint (ie, POSTing data to a GET endpoint): {}".format(
                        e.response.text
                    )
                )
            elif e.response.status_code == 406:
                raise NotAcceptableException(
                    "Content Type of the data returned does not match the Accept header of the request: {}".format(
                        e.response.text
                    )
                )
            elif e.response.status_code == 412:
                raise NotAcceptableException("Etag doesn't match: {}".format(e.response.text))
            elif e.response.status_code == 415:
                raise UnsupportedMediaTypeException(
                    "Attempting to POST data in incorrect format: {}".format(e.response.text)
                )
            elif e.response.status_code == 429:
                raise TooManyRequestsException(
                    "You have exceeded the max number of requests per 1-minute period: {}".format(e.response.text)
                )
            elif e.response.status_code == 500:
                raise InternalServerErrorException("AWX Internal Server Error")
            elif e.response.status_code == 503:
                raise ServiceUnavailableException(
                    "The ThousandEyes API is currently in maintenance mode: {}".format(e.response.text)
                )

    return wrapper
