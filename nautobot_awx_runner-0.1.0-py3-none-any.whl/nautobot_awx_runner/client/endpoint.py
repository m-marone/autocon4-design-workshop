"""Defines the API endpoint functionality."""

import json
from typing import Any
from urllib.parse import urlparse

import requests

from .errors import InvalidResponseException, error_report, ConnectionException


class Endpoint:
    """Endpoint represents an API client endpoint including a URL and method."""

    class Request:
        """A Request is an endpoint that has been prepared for calling."""

        def __init__(self, endpoint: "Endpoint", url, auth, params):
            """Create a new Request object.

            Args:
                endpoint (Endpoint): The parent endpoint that this request is for.
                url (str): The formatted URL to connect to.
                auth (tuple): Authentication information required to connect.
                params (dict): Any query params to add to the request URL.
            """
            self.endpoint = endpoint
            self.url = urlparse(url)
            self.auth = auth
            self.params = params

        @error_report
        def apply(self, payload=None) -> dict:
            """Perform the request using the HTTP method specified in the endpoint.

            Args:
                payload: If the request is an HTTP POST, the payload will be serialized to JSON
                    and send as the POST body.

            Raises:
                Exception: If the response doesn't include the expected JSON structure.

            Returns:
                Any: The content specified by the endpoint object.
            """
            if payload is not None:
                payload = json.dumps(payload)

            auth = self.auth
            if callable(auth):
                auth = auth()

            try:
                r = requests.request(
                    method=self.endpoint.method,
                    url=self.url.geturl(),
                    auth=auth,
                    headers={
                        "Accept": "application/json",
                        "Content-type": "application/json",
                    },
                    params={**self.endpoint.params, **self.params},
                    data=payload,
                )
            except requests.ConnectionError as ex:
                raise ConnectionException(f"Failed to connect to {self.url}") from ex

            r.raise_for_status()
            if r.content:
                return r.json()
            return None

        def call(self, **payload):
            """Make the request to the remote endpoint."""
            retval = self.apply(payload)
            if self.endpoint.retval is None:
                return None

            if self.endpoint.retval:
                for p in self.endpoint.retval:
                    retval = retval.get(p, None)
                    if retval is None:
                        raise InvalidResponseException("Unexpected response (data structure)")

            return retval

    class PageableRequest(Request):
        """A request that handles paging."""

        def call(self, **payload) -> Any:
            """Make the request to the remote endpoint.

            This method will yield each result in the response and
             will correctly handle next pages, iterating through
            until no more pages are available.
            """
            data = self.apply(payload)
            for result in data["results"]:
                yield result

    def __init__(self, method, url, auth=None, retval="", paging=False, params={}):
        """Initialize the endpoint."""
        self.method = method
        self.url = url
        self.auth = auth
        self.retval = None
        if retval:
            self.retval = retval.split(".")
        elif retval == "":
            self.retval = []

        self.paging = paging
        if not isinstance(params, dict):
            raise ValueError("query params must be a dictionary")
        self.params = params

    def __call__(self, **kwargs):
        """Make the request to the remote endpoint."""
        auth = None
        if "auth" in kwargs:
            auth = kwargs.pop("auth")
        elif self.auth:
            auth = self.auth

        url = self.url.format_map(kwargs)
        args = [self, url, auth, kwargs.pop("params", {})]
        if self.paging:
            return self.PageableRequest(*args)
        return self.Request(*args)
