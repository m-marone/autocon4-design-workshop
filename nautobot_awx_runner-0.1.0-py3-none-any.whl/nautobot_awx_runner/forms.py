"""Forms for the AWX runner."""
import re
from collections import Counter
from django import forms
from django.apps import apps

from nautobot.apps.forms import BootstrapMixin, DynamicModelChoiceField, DynamicModelMultipleChoiceField


def default_kwargs(spec, **kwargs):
    """The default keyword argguments for generating form elements."""
    return {
        "label": kwargs.get("question_name", spec["question_name"]),
        "help_text": kwargs.get("question_description", spec["question_description"]),
        "initial": kwargs.get("default", spec["default"]),
        "required": kwargs.get("required", spec["required"]),
    }


def create_text_field(spec, **kwargs):
    """Create a text field for an AWX survey."""
    description = spec["question_description"]
    if match := re.search(
        r"\[nautobot::(?P<app_label>\w+)\.(?P<model>\w+)(?:::(?P<query_param>\S+))?\]",
        spec["question_description"],
    ):
        query_params = {}
        app_label = match.group("app_label")
        model_name = match.group("model")
        query_param = match.group("query_param")
        if query_param:
            params = query_param.split(";")
            for param in params:
                model, value = param.split("=")
                query_params[model] = value
        model = apps.get_model(app_label, model_name)
        description = description.replace(match.group(), "")

        return spec["variable"], DynamicModelChoiceField(
            queryset=model.objects.all(),
            query_params=query_params,
            **default_kwargs(spec, question_description=description),
            **kwargs,
        )

    return spec["variable"], forms.CharField(
        **default_kwargs(spec),
        min_length=spec["min"],
        max_length=spec["max"],
        **kwargs,
    )


def create_textarea_field(spec):
    """Create a text area field for an AWX survey."""
    return create_text_field(
        spec,
        widget=forms.Textarea,
    )


def create_password_field(spec):
    """Create a password field for an AWX survey."""
    return create_text_field(
        spec,
        widget=forms.PasswordInput,
    )


def create_select_field(spec, multiple=False):
    """Create a select field for an AWX survey."""
    kwargs = default_kwargs(spec)
    spec_choices = spec["choices"]
    # nautobot_choice = None
    # for choice in spec["choices"]:
    #     if choice.startswith("nautobot::"):
    #         nautobot_choice = choice
    #     choices.append((choice, choice))
    if isinstance(spec_choices, str):
        # Split off of most common char between "," and "\n"
        counter = Counter(spec_choices)
        new_line_count = counter.get("\n", 0)
        comma_count = counter.get(",", 0)
        if new_line_count > comma_count:
            spec_choices = spec_choices.splitlines()
        else:
            spec_choices = [choice.strip() for choice in spec_choices.split(",")]
    choices = [(choice, choice) for choice in spec_choices]
    # if nautobot_choice:
    #     _, model_name = nautobot_choice.split("::")
    #     app_label, model_name, display_field = model_name.split(".")
    #     model = apps.get_model(app_label, model_name)
    #     if multiple:
    #         field = DynamicModelMultipleChoiceField(
    #             display_field=display_field,
    #             queryset=model.objects.all(),
    #             **kwargs
    #         )
    #     else:
    #         field = DynamicModelChoiceField(
    #             display_field=display_field,
    #             queryset=model.objects.all(),
    #             **kwargs
    #         )
    if multiple:
        field = forms.MultipleChoiceField(
            choices=choices,
            **kwargs,
        )
    else:
        field = forms.ChoiceField(
            choices=choices,
            **kwargs,
        )
    return spec["variable"], field


def create_multi_select_field(spec):
    """Create a multiple-select field for an AWX survey."""
    return create_select_field(spec, multiple=True)


def create_integer_field(spec):
    """Create an integer field for an AWX survey."""
    return spec["variable"], forms.IntegerField(
        **default_kwargs(spec),
        min_value=spec["min"],
        max_value=spec["max"],
    )


def create_float_field(spec):
    """Create a float field for an AWX survey."""
    return spec["variable"], forms.FloatField(
        **default_kwargs(spec),
        min_value=spec["min"],
        max_value=spec["max"],
    )


field_factories = {
    "text": create_text_field,
    "textarea": create_textarea_field,
    "password": create_password_field,
    "multiplechoice": create_select_field,
    "multiselect": create_multi_select_field,
    "integer": create_integer_field,
    "float": create_float_field,
}


def launch_form_factory(class_name, survey_spec):
    """Dynamically generate a form for launching a job with a survey."""
    fields = {}
    for field_spec in survey_spec["spec"]:
        if factory := field_factories.get(field_spec["type"]):
            name, field = factory(field_spec)
            fields[name] = field

    return type(class_name, (BootstrapMixin, forms.Form), fields)
