""""Tables for displaying results from AWX API endpoints."""

from typing import List
from django.urls import reverse
from django.utils.safestring import mark_safe

import django_tables2 as tables
from django_tables2 import Column

ALL_ACTIONS = "<p></p>"


class APIProxyTable(tables.Table):
    """A base table for displaying API results from AWX."""

    def __init__(self, *args, **kwargs):
        """Initialize the proxy table."""
        kwargs.setdefault("attrs", {})
        kwargs["attrs"]["class"] = "table table-hover table-headings"
        super().__init__(*args, **kwargs)

    @property
    def configurable_columns(self):
        """List of columns that can be displayed or hidden in the table."""
        selected_columns = [
            (name, self.columns[name].verbose_name) for name in self.sequence if name not in ["pk", "actions"]
        ]
        available_columns = [
            (name, column.verbose_name)
            for name, column in self.columns.items()
            if name not in self.sequence and name not in ["pk", "actions"]
        ]
        return selected_columns + available_columns

    @property
    def visible_columns(self):
        """List of columns that are currently displayed."""
        return [name for name in self.sequence if self.columns[name].visible]


class ActionButton:
    """Render an anchor as a button with an icon."""

    title: str = ""
    icon: str = ""
    icon_classes: List[str] = None
    link_classes: List[str] = ["btn-default"]

    def _render(self, url, attrs=None):
        href = ""
        if url:
            href = f'href="{url}"'

        link_classes = [
            "btn",
            "btn-xs",
            *self.link_classes,
        ]
        attrs = attrs or {}
        link = '<a {} class="{}" {}><i class="mdi {}" title="{}"></i></a>'.format(
            href,
            " ".join(link_classes),
            " ".join([f'{key}="{value}"' for key, value in attrs.items()]),
            self.icon,
            self.title,
        )
        return mark_safe(link)


class LaunchButton(ActionButton):
    """Display the launch button with a rocket icon."""

    title = "Launch"
    icon = "mdi-rocket"
    link_classes = ["btn-primary"]

    def __init__(self, view: str):
        """Initialize the launch button to open the given view.

        Args:
            view (str): The view name that the browser should navigate to. This should not include the `plugins:nautobot_awx_runner` prefix.
        """
        self.view = view

    def render(self, record):
        """Render the button for the associated record."""
        url = reverse(
            f"plugins:nautobot_awx_runner:{ self.view }",
            args=[record["id"]],
        )
        return self._render(url)


class ApproveButton(ActionButton):
    """Display a check icon for approving a workflow."""

    title = "Approve"
    icon = "mdi-check"
    link_classes = ["btn-success"]

    def render(self, record):
        """Render the button for the associated record."""
        if record["can_approve_or_deny"]:
            url = ""
            return self._render(
                url,
                attrs={
                    "data-id": record["id"],
                    "data-job": "Approve Workflow",
                },
            )
        return ""


class DenyButton(ActionButton):
    """Display a cancel icon for denying a workflow."""

    title = "Deny"
    icon = "mdi-cancel"
    link_classes = ["btn-danger"]

    def render(self, record):
        """Render the button for the associated record."""
        if record["can_approve_or_deny"]:
            url = ""
            return self._render(
                url,
                attrs={
                    "data-id": record["id"],
                    "data-job": "Deny Workflow",
                },
            )
        return ""


class ExternalLinkButton(ActionButton):
    """Display an `open in new` icon for an external link."""

    title = "Open"
    icon = "mdi-open-in-new"
    link_classes = []

    def render(self, record):
        """Render the button for the associated record."""
        url = record.get("url", "")
        return self._render(url, attrs={"target": "_blank"})


class ActionsColumn(tables.Column):
    """Display action buttons for list items."""

    attrs = {"td": {"class": "text-right text-nowrap noprint"}}

    def __init__(self, *buttons, **kwargs):
        """Initialize the column for the set of buttons."""
        kwargs.setdefault("accessor", "id")
        super().__init__(**kwargs)
        self.buttons = buttons

    def render(self, value, record):
        """Render all of the action buttons for the given record."""
        content = ""
        if self.buttons:
            content = self.buttons[0].render(record)
            for button in self.buttons[1:]:
                content += mark_safe("\n") + button.render(record)
        return content

    def header(self):
        """Action columns do not have a header."""
        return ""


class JobsTable(APIProxyTable):
    """Table for list view."""

    link = ActionsColumn(ExternalLinkButton())
    name = Column(linkify=("plugins:nautobot_awx_runner:job", [tables.A("id")]))
    status = Column()
    started = Column()
    finished = Column()
    workflow = Column(accessor="summary_fields__source_workflow_job__name")


class JobTemplatesTable(APIProxyTable):
    """Table for list view."""

    link = ActionsColumn(ExternalLinkButton())
    name = Column(linkify=("plugins:nautobot_awx_runner:job_template", [tables.A("id")]))
    status = Column()
    started = Column()
    finished = Column()
    playbook = Column()

    actions = ActionsColumn(
        LaunchButton("job_template_launch"),
    )


class WorkflowJobTemplatesTable(APIProxyTable):
    """Table for list view."""

    link = ActionsColumn(ExternalLinkButton())
    name = Column(linkify=("plugins:nautobot_awx_runner:workflow_job_template", [tables.A("id")]))
    description = Column()

    actions = ActionsColumn(
        LaunchButton("workflow_job_template_launch"),
    )


class WorkflowApprovalTable(APIProxyTable):
    """Table for list view."""

    link = ActionsColumn(ExternalLinkButton())
    name = Column(linkify=("plugins:nautobot_awx_runner:workflow_approval", [tables.A("id")]))
    status = Column()
    started = Column()
    finished = Column()

    actions = ActionsColumn(
        ApproveButton(),
        DenyButton(),
    )
