from django import template
from django.utils.html import escape
from django.utils.safestring import SafeString

from ansi2html import Ansi2HTMLConverter

register = template.Library()


@register.filter(name="convert_stdout")
def convert_stdout(output):
    converter = Ansi2HTMLConverter()
    content = SafeString("")
    for line in output.splitlines():
        if line:
            line = converter.convert(line, full=False)
            content += SafeString(f'<div class="output-line">{line}</div>')
        else:
            content += SafeString('<div class="output-line">&nbsp;</div>')
    return content
