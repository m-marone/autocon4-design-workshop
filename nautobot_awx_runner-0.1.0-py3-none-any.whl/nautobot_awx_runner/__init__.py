"""Plugin declaration for nautobot_awx_runner."""
# Metadata is inherited from Nautobot. If not including Nautobot in the environment, this should be added
from importlib import metadata

__version__ = metadata.version(__name__)

from django.utils.functional import classproperty
from django.conf import settings

from nautobot.extras.plugins import NautobotAppConfig

from .client import AWXClient


class NautobotAWXRunnerConfig(NautobotAppConfig):
    """Plugin configuration for the nautobot_awx_runner plugin."""

    name = "nautobot_awx_runner"
    verbose_name = "Nautobot AWX Runner"
    version = __version__
    author = "Network to Code, LLC"
    description = "A Nautobot App for interacting with AWX/AAP."
    base_url = "nautobot-awx-runner"
    required_settings = []
    min_version = "1.0"
    max_version = "2.9999"
    default_settings = {}
    caching_config = {}

    _client = None

    @classproperty
    def settings(cls):
        """Get the dictionary of settings for this config object."""
        return settings.PLUGINS_CONFIG[cls.name]

    @classproperty
    def client(cls) -> AWXClient:
        """Get the current AWXClient instance."""
        if cls._client is None:
            cls._client = AWXClient(
                base_url=cls.settings["base_url"], username=cls.settings["username"], password=cls.settings["password"]
            )
        return cls._client


config = NautobotAWXRunnerConfig  # pylint:disable=invalid-name
