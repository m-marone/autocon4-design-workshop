from contextlib import contextmanager
import json
from os import path
import random
from string import Formatter
from unittest import TestCase
import requests_mock

from nautobot_awx_runner.client import AWXClient

DATA_DIR = path.join(path.dirname(__file__), "testdata")
BASE_URL = "http://localhost"


@requests_mock.Mocker()
class TestAWXClient(TestCase):
    def setUp(self):
        super().setUp()
        self.client = AWXClient(f"{BASE_URL}/api/v2", "testuser", "testpassword")
        self.base_url = f"{BASE_URL}/api/v2"

    def test_api_suffix(self, m: requests_mock.Mocker):
        self.assertEqual(BASE_URL, self.client.base_url)

    @contextmanager
    def run_test(self, method, url, **response):
        with requests_mock.Mocker() as m:
            m.register_uri(method, f"{self.base_url}{url}", **response)
            yield m
            self.assertEqual(1, m.call_count)
            self.assertEqual(method, m.request_history[0].method)

    def parse_url(self, url):
        f = Formatter()
        args = {}
        tokens = []
        for literal_text, field_name, format_spec, conversion in f.parse(url):
            tokens.append(literal_text)
            if field_name:
                value = random.randint(1, 15000)
                args[field_name] = value
                if conversion:
                    value = f.convert_field(value, conversion)
                tokens.append(format(value, format_spec))

        return "".join(tokens), args

    def generate_result(self, url):
        want = {"url": url}
        result = want
        url_path = path.join(DATA_DIR, *url.split("/"))
        response_file = path.join(url_path, "response.json")
        if path.exists(response_file):
            with open(response_file) as file:
                result = json.load(file)

            want_file = path.join(url_path, "want.txt")
            if path.exists(want_file):
                with open(want_file) as file:
                    want = file.read()

        return want, result

    def single_result_test(self, url, client_method, want=None, result=None):
        mock_url, kwargs = self.parse_url(url)
        if want is None and result is None:
            want, result = self.generate_result(url)

        with self.run_test("GET", mock_url, json=result):
            self.maxDiff = 50000
            self.assertEqual(want, client_method(**kwargs))

    def multiple_results_test(self, url, client_method):
        mock_url, kwargs = self.parse_url(url)
        want = [random.randint(1, 15000) for i in range(20)]
        result = {"count": len(want), "results": want}
        with self.run_test("GET", mock_url, json=result):
            got = [result for result in client_method(**kwargs)]
            self.assertEqual(want, got)

    def test_get_endpoints(self, m: requests_mock.Mocker):
        multi = self.multiple_results_test
        single = self.single_result_test

        # , want=want, result=result,
        test_cases = (
            (
                multi,
                "/hosts/",
                self.client.get_hosts,
            ),
            (
                single,
                "/jobs/{id}/",
                self.client.get_job,
            ),
            (single, "/jobs/{id}/stdout/", self.client.get_job_stdout),
            (
                single,
                "/job_templates/{id}/",
                self.client.get_job_template,
            ),
            (
                multi,
                "/job_templates/",
                self.client.get_job_templates,
            ),
            (
                multi,
                "/jobs/",
                self.client.get_jobs,
            ),
            (
                single,
                "/workflow_approvals/{id}/",
                self.client.get_workflow_approval,
            ),
            (
                multi,
                "/workflow_approvals/",
                self.client.get_workflow_approvals,
            ),
            (
                multi,
                "/workflow_job_templates/",
                self.client.get_workflow_job_templates,
            ),
            (
                multi,
                "/workflow_jobs/{id}/workflow_nodes/",
                self.client.get_workflow_job_workflow_nodes,
            ),
            (
                multi,
                "/workflow_jobs/",
                self.client.get_workflow_jobs,
            ),
        )

        for tester, url, client_method in test_cases:
            with self.subTest(url):
                tester(url, client_method)

    def test_get_job_ui_url(self, m):
        self.assertEqual(f"{BASE_URL}/#/jobs/playbook/47", self.client.get_job_ui_url(47))

    def test_approve_workflow_approval(self, m: requests_mock.Mocker):
        with self.run_test("POST", "/workflow_approvals/42/approve/"):
            self.assertIsNone(self.client.approve_workflow_approval(42))

    def test_launch_job_template(self, m: requests_mock.Mocker):
        result = {
            "ask_variables_on_launch": True,
            "ask_tags_on_launch": False,
            "ask_skip_tags_on_launch": True,
            "ask_job_type_on_launch": True,
            "ask_limit_on_launch": False,
            "ask_inventory_on_launch": True,
            "ask_credential_on_launch": False,
            "can_start_without_user_input": False,
            "passwords_needed_to_start": ["none"],
            "variables_needed_to_start": ["host"],
            "survey_enabled": False,
            "inventory_needed_to_start": False,
        }

        with self.run_test("POST", "/job_templates/43/launch/", json=result) as m:
            self.assertEqual(result, self.client.launch_job_template(43, host="my-host"))
            self.assertEqual({"host": "my-host"}, m.request_history[0].json())

    def test_launch_workflow_job_template(self, m: requests_mock.Mocker):
        with self.run_test("POST", "/workflow_job_templates/49/launch/"):
            self.assertIsNone(self.client.launch_workflow_job_template(49))
