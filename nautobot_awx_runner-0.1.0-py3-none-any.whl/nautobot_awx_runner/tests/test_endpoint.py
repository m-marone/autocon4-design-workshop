from unittest import TestCase
from unittest.mock import Mock, patch

import requests_mock

from nautobot_awx_runner.client.endpoint import Endpoint
from nautobot_awx_runner.client.errors import InvalidResponseException

BASE_URL = "http://awx.local"


class TestEndpoint(TestCase):
    def test_retval(self):
        endpoint = Endpoint("", "", retval="one.two")
        self.assertEqual(["one", "two"], endpoint.retval)

    def test_empty_retval(self):
        endpoint = Endpoint("", "")
        self.assertEqual([], endpoint.retval)

    def test_no_retval(self):
        endpoint = Endpoint("", "", retval=None)
        self.assertEqual(None, endpoint.retval)

    def test_invalid_params(self):
        self.assertRaises(ValueError, Endpoint, "", "", params=None)

    def test_attributes_were_set(self):
        endpoint = Endpoint("PATCH", "my_url")
        self.assertEqual("PATCH", endpoint.method)
        self.assertEqual("my_url", endpoint.url)
        self.assertEqual([], endpoint.retval)
        self.assertFalse(endpoint.paging)
        self.assertEqual({}, endpoint.params)

        endpoint = Endpoint("PATCH", "my_url", retval="results", paging=True, params={"query": "params"})
        self.assertEqual("PATCH", endpoint.method)
        self.assertEqual("my_url", endpoint.url)
        self.assertEqual(["results"], endpoint.retval)
        self.assertTrue(endpoint.paging)
        self.assertEqual({"query": "params"}, endpoint.params)

    def test_call(self):
        endpoint = Endpoint("PATCH", "my_url/{id}")
        request = endpoint(id=1234)
        self.assertEqual(type(request), Endpoint.Request)

        self.assertEqual("my_url/1234", request.url)
        self.assertIsNone(request.auth)
        self.assertEqual({}, request.params)

    def test_call_with_auth(self):
        endpoint = Endpoint("PATCH", "my_url")
        request = endpoint(auth=("user", "pass"))
        self.assertEqual(type(request), Endpoint.Request)

        self.assertEqual("my_url", request.url)
        self.assertEqual(("user", "pass"), request.auth)
        self.assertEqual({}, request.params)

    def test_call_with_params(self):
        endpoint = Endpoint("PATCH", "my_url/")
        request = endpoint(params={"q1": "search"})
        self.assertEqual(type(request), Endpoint.Request)

        self.assertEqual("my_url/", request.url)
        self.assertIsNone(request.auth)
        self.assertEqual({"q1": "search"}, request.params)

    def test_call_with_paging(self):
        endpoint = Endpoint("PATCH", "my_url/", paging=True)
        request = endpoint()
        self.assertEqual(type(request), Endpoint.PageableRequest)


class TestEndpointRequest(TestCase):
    @patch("nautobot_awx_runner.client.endpoint.requests.request")
    def test_apply_get(self, mock_request: Mock):
        endpoint = Endpoint("GET", "my_url/{id}")
        request = endpoint(id=1234)
        request.apply()

        mock_request.assert_called_with(
            method="GET",
            url="my_url/1234",
            auth=None,
            headers={
                "Accept": "application/json",
                "Content-type": "application/json",
            },
            params={},
            data=None,
        )

    @patch("nautobot_awx_runner.client.endpoint.requests.request")
    def test_apply_post(self, mock_request: Mock):
        endpoint = Endpoint("POST", "my_url/{id}")
        request = endpoint(id=1234)
        request.apply({"some": "data to be posted"})

        mock_request.assert_called_with(
            method="POST",
            url="my_url/1234",
            auth=None,
            headers={
                "Accept": "application/json",
                "Content-type": "application/json",
            },
            params={},
            data='{"some": "data to be posted"}',
        )

    def run_call_test(self, return_value, retval=None):
        with requests_mock.Mocker() as m:
            m.register_uri("GET", "http://localhost/my_url/", json=return_value)

            endpoint = Endpoint("GET", "http://localhost/my_url/", retval=retval)
            request = endpoint()
            return request.call()

    def test_call_without_retval(self):
        want = {"results": [1, 2, 3, 4, 5]}
        got = self.run_call_test(want)
        self.assertEqual(want, got)

    def test_call_with_retval(self):
        want = [1, 2, 3, 4, 5]
        return_value = {"results": want}
        got = self.run_call_test(return_value, "results")
        self.assertEqual(want, got)

    def test_call_with_retval_none(self):
        return_value = {"results": [1, 2, 3, 4, 5]}
        got = self.run_call_test(return_value, None)
        self.assertIsNone(got)

    def test_call_with_invalid_response(self):
        return_value = {"results": [1, 2, 3, 4, 5]}
        self.assertRaises(InvalidResponseException, self.run_call_test, return_value, "no_results")


class TestEndpointPageableRequest(TestCase):
    def setUp(self):
        super().setUp()
        self.base_url = "http://localhost/my_url/"

    def run_call_test(self, responses, want):
        with requests_mock.Mocker() as m:
            previous = None
            for response in responses:
                url = previous["next"] if previous else self.base_url
                m.register_uri("GET", url, json=response)
                previous = response

            endpoint = Endpoint("GET", self.base_url, paging=True)
            request = endpoint()
            got = []
            for result in request.call():
                got.append(result)

            self.assertEqual(want, got)

    def generate_responses(self, per_page, total, result_generator):
        previous_page = None
        responses = []
        for i in range(0, total, per_page):
            page = int(i / 10) + 1
            if per_page * page < total:
                next_page = f"{self.base_url}?page={page+1}"
            else:
                next_page = None

            count = per_page
            if i + per_page >= total:
                count = total - i
            results = [result_generator(i + j) for j in range(count)]

            responses.append({"count": total, "next": next_page, "previous": previous_page, "results": results})
            previous_page = next_page
        return responses

    def test_call_with_one_page(self):
        results = [{"result": f"result {i}"} for i in range(10)]
        responses = self.generate_responses(len(results), len(results), lambda i: results[i])
        self.run_call_test(responses, results)

    def test_call_with_multiple_pages(self):
        results = [{"result": f"result {i}"} for i in range(100)]
        responses = self.generate_responses(10, len(results), lambda i: results[i])
        self.run_call_test(responses, results)

    def test_call_with_less_than_full_pages(self):
        results = [{"result": f"result {i}"} for i in range(42)]
        responses = self.generate_responses(10, len(results), lambda i: results[i])
        self.run_call_test(responses, results)

    def test_call_with_less_than_one_page(self):
        results = [{"result": f"result {i}"} for i in range(42)]
        responses = self.generate_responses(50, len(results), lambda i: results[i])
        self.run_call_test(responses, results)
