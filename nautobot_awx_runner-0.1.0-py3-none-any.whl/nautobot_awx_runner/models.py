from django.db import models


class Job(models.Model):
    class Meta:
        managed = False
        default_permissions = ("view",)


class JobTemplate(models.Model):
    class Meta:
        managed = False
        default_permissions = ("view",)

        permissions = (("launch", "Launch a Job Template"),)


class WorkflowApproval(models.Model):
    class Meta:
        managed = False
        default_permissions = ("view",)

        permissions = (
            ("approve", "Approve a workflow"),
            ("deny", "Deny a workflow"),
        )


class WorkflowJobTemplate(models.Model):
    class Meta:
        managed = False
        default_permissions = ("view",)

        permissions = (("launch", "Launch a Workflow Job Template"),)
