"""Management command to populate sample data for testing and demonstration."""

import os

from django.core.management.base import BaseCommand
from django.core.management import call_command


class Command(BaseCommand):
    """Populate the database with sample data. This command is idempotent."""

    def handle(self, *args, **options):
        """Handle the execution of the populate command."""
        self.stdout.write("Attempting to populate sample data.")
        fixtures = os.listdir(os.path.join(os.path.dirname(__file__), "..", "..", "fixtures"))
        fixtures.sort()
        print("Loading", fixtures)
        call_command("loaddata", *fixtures, **{"verbosity": 0})
        self.stdout.write(self.style.SUCCESS("Successfully populated database."))
