"""Nautobot Jobs that interact with remote AWX jobs."""
import json

from nautobot.apps.jobs import Job, register_jobs, IntegerVar, TextVar

from nautobot_awx_runner import NautobotAWXRunnerConfig, models
from nautobot_awx_runner.client.errors import AWXException


class BaseJob(Job):
    """Common code for making AWX requests."""

    def _run(self, id, fail_msg=None, success_msg=None, extra_vars=None):
        user = self.user
        permission = self.Meta.permission_required
        model_name = self.Meta.model._meta.model_name
        permissions = [
            f"nautobot_awx_runner.{permission}_{model_name}",
            f"nautobot_awx_runner.{permission}_{id}_{model_name}",
        ]
        has_permission = False
        for permission in permissions:
            if user.has_perm(permission):
                has_permission = True
                break

        if not has_permission:
            self.logger.error(f"{user} does not have permission to run job {id}")
            raise Exception("Not authorized")

        if extra_vars:
            try:
                extra_vars = json.loads(extra_vars)
            except json.JSONDecodeError as ex:
                self.logger.fatal(
                    "Failed to decode extra vars JSON. Make sure extra vars is a valid JSON object: %s", ex
                )
                raise Exception("Invalid extra vars JSON.")

            if not isinstance(extra_vars, dict):
                self.logger.fatal("Extra vars must be a valid JSON object (not a list)")
                raise Exception("Invalid extra vars JSON.")
        else:
            extra_vars = {}

        try:
            self.Meta.endpoint(id, **extra_vars)
            if success_msg:
                self.logger.info(success_msg)
        except AWXException as ex:
            if fail_msg:
                self.logger.fatal("%s: %s", fail_msg, str(ex))
            raise ex


class LaunchWorkflowTemplate(BaseJob):
    """Launch a workflow job template."""

    template_id = IntegerVar(label="Workflow Template ID", min_value=0)
    extra_vars = TextVar(label="Extra Vars", required=False)

    class Meta:
        name = "Launch Workflow Template"
        description = "Launch an AWX Workflow Template"
        has_sensitive_variables = True
        endpoint = NautobotAWXRunnerConfig.client.launch_workflow_job_template
        model = models.WorkflowJobTemplate
        permission_required = "launch"

    def run(self, template_id, extra_vars):
        """Launch the remote AWX workflow template."""
        self.logger.info("Launching workflow template...")
        self._run(
            template_id,
            fail_msg="Failed to launch workflow",
            success_msg="Workflow launched successfully",
            extra_vars=extra_vars,
        )


class LaunchJobTemplate(BaseJob):
    """Launch an AWX job template."""

    template_id = IntegerVar(label="Job Template ID", min_value=0)
    extra_vars = TextVar(label="Extra Vars", required=False)

    class Meta:
        name = "Launch Job Template"
        description = "Launch an AWX Job Template"
        has_sensitive_variables = True
        endpoint = NautobotAWXRunnerConfig.client.launch_job_template
        model = models.JobTemplate
        permission_required = "launch"

    def run(self, template_id, extra_vars):
        """Launch the remote AWX job template."""
        self.logger.info("Launching job template...")
        self._run(
            template_id,
            fail_msg="Failed to launch job",
            success_msg="Job launched successfully",
            extra_vars=extra_vars,
        )


class ApproveWorkflow(BaseJob):
    """Mark a workflow approval as `approved`."""

    id = IntegerVar(label="ID", min_value=0)

    class Meta:
        name = "Approve Workflow"
        description = "Approve a pending AWX Workflow"
        has_sensitive_variables = True
        endpoint = NautobotAWXRunnerConfig.client.approve_workflow_approval
        model = models.WorkflowApproval
        permission_required = "approve"

    def run(self, id):
        """Approve the workflow approval."""
        self.logger.info("Sending approval...")
        self._run(
            id,
            fail_msg="Failed to approve workflow",
            success_msg="Approved workflow",
        )


class DenyWorkflow(BaseJob):
    """Mark the workflow approval as denied."""

    id = IntegerVar(label="ID", min_value=0)

    class Meta:
        name = "Deny Workflow"
        description = "Deny a pending AWX Workflow"
        has_sensitive_variables = True
        endpoint = NautobotAWXRunnerConfig.client.approve_workflow_approval
        model = models.WorkflowApproval
        permission_required = "deny"

    def run(self, id):
        """Deny the workflow approval request."""
        self.logger.info("Sending denial...")
        self._run(
            id,
            fail_msg="Failed to deny workflow",
            success_msg="Denied workflow",
        )


name = "AWX Runner"
register_jobs(
    LaunchWorkflowTemplate,
    LaunchJobTemplate,
    ApproveWorkflow,
    DenyWorkflow,
)
